beerService = (function () {

    var findById = function (id) {
            var deferred = $.Deferred();
            var beer = null;
            var l = beers.length;
            for (var i = 0; i < l; i++) {
                if (beers[i].id == id) {
                    beer = beers[i];
                    break;
                }
            }
            deferred.resolve(beer);
            return deferred.promise();
        },

        findByName = function (searchKey) {
            var deferred = $.Deferred();
            var results = beers.filter(function (element) {
                var fullName = element.beerName + " " + element.breweryName;
                return fullName.toLowerCase().indexOf(searchKey.toLowerCase()) > -1;
            });
            deferred.resolve(results);
            return deferred.promise();
        },
        
        beers = [
            {"id": 1, "beerName": "IPA", "breweryName": "Good People", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 2, "beerName": "Pale", "breweryName": "Good People",  "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 3, "beerName": "Brown", "breweryName": "Good People",  "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 4, "beerName": "Snakehandler", "breweryName": "Good People",  "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 5, "beerName": "Coffe Oatmeal Stout", "breweryName": "Good People", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 6, "beerName": "Bearded Lady", "breweryName": "Good People","type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 7, "beerName": "Urban Farmer", "breweryName": "Good People",  "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 8, "beerName": "Muchacho", "breweryName": "Good People",  "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 9, "beerName": "JUCO", "breweryName": "Good People",  "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 10, "beerName": "Hitchhiker", "breweryName": "Good People", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 11, "beerName": "Mumbai Rye", "breweryName": "Good People",  "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 12, "beerName": "Denim Downhiller", "breweryName": "Good People", "title": "Software Architect", "department": "Engineering", "mobilePhone": "617-000-0012", "officePhone": "781-000-0012", "email": "swells@fakemail.com", "city": "Boston, MA", "pic": "steven_wells.jpg", "twitterId": "@fakeswells", "blog": "http://coenraets.org"},
            {"id": 13, "beerName": "IPA", "breweryName": "TrimTab", "type": "IPA", "ABV": "6.5%", "IBU": "61", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 14, "beerName": "Pillar to Post Rye Brown", "breweryName": "TrimTab", "type": "Brown", "ABV": "5.5%", "IBU": "41", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 15, "beerName": "Rescue Ship Pale Ale", "breweryName": "TrimTab", "type": "Pale", "ABV": "5.5%", "IBU": "18", "seasonal": "yes", "pic": "james_king.jpg"},
            {"id": 16, "beerName": "Imperial City Olde Ale", "breweryName": "TrimTab", "type": "English Ale", "ABV": "7.3%", "IBU": "55.5", "seasonal": "Yes", "pic": "james_king.jpg"},
            {"id": 17, "beerName": "Bankston 88", "breweryName": "TrimTab", "type": "Belgian", "ABV": "4.5%", "IBU": "31", "seasonal": "Yes", "pic": "james_king.jpg"},
            {"id": 18, "beerName": "Raspberry Berliner Weisse", "breweryName": "TrimTab", "type": "Berliner Weisse", "ABV": "5.2%", "IBU": "7", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 19, "beerName": "Craft Lager", "breweryName": "Ghost Train", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 20, "beerName": "Go-Devil Golden Ale", "breweryName": "Ghost Train", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 21, "beerName": "Terminal Station Brown Ale", "breweryName": "Ghost Train", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 22, "beerName": "Switchman's Stash IPL", "breweryName": "Ghost Train", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 23, "beerName": "Kaleidoscope Kettle Sour", "breweryName": "Ghost Train", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 24, "beerName": "Spring Street Saison", "breweryName": "Avondale", "type": "Belgian", "ABV": "7.2%", "IBU": "18", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 25, "beerName": "Miss Fancy's Tripel", "breweryName": "Avondale", "type": "Belgian", "ABV": "9.2%", "IBU": "20", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 26, "beerName": "Battlefield IPA", "breweryName": "Avondale", "type": "IPA", "ABV": "6.8%", "IBU": "62", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 27, "beerName": "Vanillaphant Porter", "breweryName": "Avondale", "type": "Porter", "ABV": "6.2%", "IBU": "25", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 28, "beerName": "Mill City White", "breweryName": "Avondale", "type": "Belgian", "ABV": "5%", "IBU": "16", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 29, "beerName": "Train Hopper", "breweryName": "Avondale", "type": "Pale", "ABV": "5.5%", "IBU": "50", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 30, "beerName": "Streetcar", "breweryName": "Avondale", "type": "Kolsch", "ABV": "4.3%", "IBU": "22", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 31, "beerName": "No Joka Mocha", "breweryName": "Avondale", "type": "Stout", "ABV": "7.2%", "IBU": "21", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 32, "beerName": "IPA", "breweryName": "Avondale", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},
            {"id": 33, "beerName": "IPA", "breweryName": "Avondale", "type": "IPA", "ABV": "7.1%", "IBU": "75.5", "seasonal": "No", "pic": "james_king.jpg"},

            ];

    // The public API
    return {
        findById: findById,
        findByName: findByName,
    };

}());