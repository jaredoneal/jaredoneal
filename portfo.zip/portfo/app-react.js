var Header = React.createClass({
    render: function () {
        return (
            <header className="bar bar-nav">
                <a href="#" className={"icon icon-left-nav pull-left" + (this.props.back==="true"?"":" hidden")}></a>
                <h1 className="title">{this.props.text}</h1>
            </header>
        );
    }
});

var SearchBar = React.createClass({
    getInitialState: function() {
        return {searchKey: ""};
    },
    searchHandler: function(event) {
        var searchKey = event.target.value;
        this.setState({searchKey: searchKey});
        this.props.searchHandler(searchKey);
    },
    render: function () {
        return (
            <div className="bar bar-standard bar-header-secondary">
                <div className="search-container">
                <span className="searchButton fa fa-search"></span>            
                <input className="searchTerm" type="search"  value={this.state.searchKey} onChange={this.searchHandler}/>
                
            </div>
            </div>

        );
    },
    componentDidMount: function() {
        this.props.searchHandler(this.state.searchKey);
    }
});

var BeerListItem = React.createClass({
    render: function () {
        return (
            <li className="beer-list item">
                <a className="beer-details" href={"#beers/" + this.props.beer.id}>
                    <img className="media-object small pull-left" src={"pics/" + this.props.beer.breweryName + ".png" }/>
                    <div>
                   <span>{this.props.beer.breweryName} </span>
                   {" "}
                   <span className="beer-name">{this.props.beer.beerName} </span>
                   {this.props.beer.title}                  
                   </div>
                </a>
            </li>
        );
    }
});

var BeerList = React.createClass({
    render: function () {
        var items = this.props.beers.map(function (beer) {
            return (
                <BeerListItem key={beer.id} beer={beer} />
            );
        });
        return (
            <div  className="table-view">
                {items}
            </div>
        );
    }
});

var HomePage = React.createClass({
    render: function () {
        return (
            <div className={"page " + this.props.position}>
                <div className="beer-background">
                <Header text="Birmingham Brews" back="false"/>
                <SearchBar searchKey={this.props.searchKey} searchHandler={this.props.searchHandler}/>
                <div className="content">
                    <BeerList beers={this.props.beers}/>
                </div>
                </div>
            </div>
        );
    }
});

var BeerPage = React.createClass({
    getInitialState: function() {
        return {beer: {}};
    },
    componentDidMount: function() {
        this.props.service.findById(this.props.beerId).done(function(result) {
            this.setState({beer: result});
        }.bind(this));
    },
    render: function () {
        return (
            <div className={"page " + this.props.position}>
                <Header text="Beer" back="true"/>
                <div className="card">
                    <ul className="table-view">
                        <li className="table-view-cell media">
                            <img className="media-object big pull-left" src={"pics/" + this.state.beer.beerName + "_" + this.state.beer.breweryName + ".jpg" }/>
                            <h1>{this.state.beer.beerName} {this.state.beer.breweryName}</h1>
                            <p>{this.state.beer.title}</p>
                        </li>                   
                    </ul>
                </div>
            </div>
        );
    }
});

var App = React.createClass({
    getInitialState: function() {
        return {
            searchKey: '',
            beers: []
        }
    },
    searchHandler: function(searchKey) {
        beerService.findByName(searchKey).done(function(beers) {
            this.setState({
                searchKey:searchKey,
                beers: beers,
                pages: [<HomePage searchHandler={this.searchHandler} searchKey={searchKey} beers={beers}/>]});
        }.bind(this));
    },
    render: function () {
        return (
            <div className="pageslider-container">
                {this.state.pages}
            </div>
        );
    }
});

React.render(<App/>, document.getElementById('appDiv'));